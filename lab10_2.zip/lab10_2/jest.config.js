module.exports = {
  testEnvironment: "node",
}
