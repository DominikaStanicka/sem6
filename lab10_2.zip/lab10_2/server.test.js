const mongoose = require("mongoose")
const supertest = require("supertest")
const createServer = require("./server")
const Post = require("./models/Post")

let app

beforeEach(async () => {
  await mongoose.connect("mongodb://localhost:27017/postsdb", {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  app = createServer()
})

afterEach(async () => {
  await mongoose.connection.dropDatabase()
  await mongoose.connection.close()
})

test("GET /posts", async () => {
  const post = await Post.create({ title: "Post 1", content: "Tekst postu 1" })

  await supertest(app)
    .get("/api/posts")
    .expect(200)
    .then((response) => {
      expect(Array.isArray(response.body)).toBeTruthy()
      expect(response.body.length).toEqual(1)
      expect(response.body[0]._id).toBe(post.id)
      expect(response.body[0].title).toBe(post.title)
      expect(response.body[0].content).toBe(post.content)
    })
})

test("POST /posts", async () => {
  const data = { title: "Post 2", content: "Treść posta 2" }

  await supertest(app)
    .post("/api/posts")
    .send(data)
    .expect(200)
    .then(async (response) => {
      expect(response.body._id).toBeTruthy()
      expect(response.body.title).toBe(data.title)
      expect(response.body.content).toBe(data.content)

      const post = await Post.findOne({ _id: response.body._id })
      expect(post).toBeTruthy()
      expect(post.title).toBe(data.title)
      expect(post.content).toBe(data.content)
    })
})

test("DELETE /posts/:id", async () => {
  const post = await Post.create({ title: "Do usunięcia", content: "Test usuwania" })

  await supertest(app)
    .delete(`/api/posts/${post._id}`)
    .expect(204)

  const found = await Post.findById(post._id)
  expect(found).toBeNull()
})
